package uz.oshxonahisob

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun showHome() {
        val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(28,24,28,24)
        val title=TextView(this); title.text="Oshxona Hisob"; title.textSize=28f; l.addView(title)
        listOf("🍖 Qiyma shashlik","🍚 Osh","🥟 Gumma / Perashka","👷 Ishchilar","📦 Mahsulotlar","💰 Sotuv","📊 Hisobot").forEach { name ->
            val b=Button(this); b.text=name; b.setOnClickListener { when(name){ "📦 Mahsulotlar"->products(); "💰 Sotuv"->sales(); "📊 Hisobot"->report(); else->simple(name) } }; l.addView(b) }
        setContentView(l)
    }
    private fun products(){ form("Mahsulotlar", listOf("Mahsulot nomi","Miqdori","Narxi (so'm)"), "Saqlash") { showHome() } }
    private fun sales(){ form("Sotuv", listOf("Mahsulot/taom","Soni","Sotuv narxi (so'm)"), "Saqlash") { showHome() } }
    private fun report(){ val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(28,24,28,24); val t=TextView(this); t.text="📊 Hisobot\n\nTushum: ${prefs.getLong("sales",0)} so'm\nXarajat: ${prefs.getLong("cost",0)} so'm\nFoyda: ${prefs.getLong("profit",0)} so'm"; t.textSize=20f; l.addView(t); val b=Button(this); b.text="Orqaga"; b.setOnClickListener{showHome()}; l.addView(b); setContentView(l) }
    private fun simple(title:String){ form(title,listOf("Nomi","Miqdori / soni","Narxi yoki foizi"),"Saqlash"){showHome()} }
    private fun form(title:String, labels:List<String>, button:String, done:()->Unit){ val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(28,24,28,24); val h=TextView(this); h.text=title; h.textSize=25f; l.addView(h); labels.forEach{ val e=EditText(this); e.hint=it; l.addView(e) }; val b=Button(this); b.text=button; b.setOnClickListener{ Toast.makeText(this,"Saqlandi",Toast.LENGTH_SHORT).show(); done() }; l.addView(b); val back=Button(this); back.text="Orqaga"; back.setOnClickListener{showHome()}; l.addView(back); setContentView(l) }
}
